খাতা — Appwright APK package

ফাইল বিন্যাস:
- index.html
- assets/style.css
- assets/app.js

গুরুত্বপূর্ণ:
- এই প্যাকেজে মূল অ্যাপের Firebase configuration এবং Firebase/Firestore integration bundle-এ রাখা হয়েছে।
- Firebase প্রকল্প বা Firestore rules পরিবর্তন করা হয়নি।
- লাইভ সার্ভার endpoint আগের build-এর মতোই রাখা হয়েছে।
- Appwright-এ ZIP import করে Android build করুন।
- Gmail/Google sign-in কাজ করার জন্য Appwright/WebView-এ Google OAuth popup/redirect এবং Firebase Auth domain অনুমোদিত থাকতে হবে।
- Appwright build সফল হওয়া মানেই Firebase/Google login device-এ সফল হবে—এ নিশ্চয়তা নয়; APK install করে login ও দুই ডিভাইসে sync পরীক্ষা করুন।
